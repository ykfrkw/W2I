##Data cleaning
# PREPARE -----------------------------------------------------------------
## clear settings

Sys.setenv(LANGUAGE="en_US.UTF-8")
rm(list=ls())   ###clears memory
cat("\014")   ###clears console
if(!is.null(dev.list())) dev.off() ###clears plots

## library
library(dplyr)
library(openxlsx)
library(meta)
library(netmeta)
library(tidyr)

# RAW ---------------------------------------------------------------------
## load data
data_raw <- read.xlsx("W2I_DE.xlsx",sheet = "Sheet1",startRow = 2,check.names=TRUE)
data <- data_raw %>% dplyr::filter(!is.na(t))


## set data
data <- data %>%
  mutate(t_raw = t,
         t = case_when(
           t == "COM" ~ "Combination",
           t == "PSY" ~ "CBT-I",
           t == "PHA" ~ "Pharmacotherapy",
           TRUE ~ as.character(t)
         )) %>%
  filter(t!="Placebo")%>%
  arrange(study, t)

#as.numeric
data <- data %>%
  mutate(year = substr(study, nchar(study) - 3, nchar(study))) %>%
  mutate_at(vars(n_randomized, r, n_dropout, n_cont,m,sd,
                 n_pt_randomized, r_pt, n_dropout_pt, n_cont_pt,m_pt,sd_pt,
                 n_female,
                 pt_w,fu_w,year,
                 baseline_n,baseline_m,baseline_sd,
                 age_n,age_m,age_sd,
                 SE_n,SE_m,SE_sd,
                 TST_n,TST_m,TST_sd,
                 SL_n,SL_m,SL_sd,
                 WASO_n,WASO_m,WASO_sd,
                 SE_n_pt,SE_m_pt,SE_sd_pt,
                 TST_n_pt,TST_m_pt,TST_sd_pt,
                 SL_n_pt,SL_m_pt,SL_sd_pt,
                 WASO_n_pt,WASO_m_pt,WASO_sd_pt
                 ), 
            as.numeric)


## impute sd -----
### age_sd
# average age_sd
avg_age_sd <- mean(data$age_sd, na.rm = TRUE)
# impute
data$age_sd[is.na(data$age_sd) & !is.na(data$age_m)] <- avg_age_sd



### SE_sd, TST_sd, SL_sd, WASO_sd, SE_sd_pt, TST_sd_pt, SL_sd_pt, WASO_sd_pt
# average SDs
avg_SE_sd <- mean(data$SE_sd, na.rm = TRUE)
avg_TST_sd <- mean(data$TST_sd, na.rm = TRUE)
avg_SL_sd <- mean(data$SL_sd, na.rm = TRUE)
avg_WASO_sd <- mean(data$WASO_sd, na.rm = TRUE)
avg_SE_sd_pt <- mean(data$SE_sd_pt, na.rm = TRUE)
avg_TST_sd_pt <- mean(data$TST_sd_pt, na.rm = TRUE)
avg_SL_sd_pt <- mean(data$SL_sd_pt, na.rm = TRUE)
avg_WASO_sd_pt <- mean(data$WASO_sd_pt, na.rm = TRUE)

# impute average SDs
data$SE_sd[is.na(data$SE_sd) & !is.na(data$SE_m)] <- avg_SE_sd
data$TST_sd[is.na(data$TST_sd) & !is.na(data$TST_m)] <- avg_TST_sd
data$SL_sd[is.na(data$SL_sd) & !is.na(data$SL_m)] <- avg_SL_sd
data$WASO_sd[is.na(data$WASO_sd) & !is.na(data$WASO_m)] <- avg_WASO_sd
data$SE_sd_pt[is.na(data$SE_sd_pt) & !is.na(data$SE_m_pt)] <- avg_SE_sd_pt
data$TST_sd_pt[is.na(data$TST_sd_pt) & !is.na(data$TST_m_pt)] <- avg_TST_sd_pt
data$SL_sd_pt[is.na(data$SL_sd_pt) & !is.na(data$SL_m_pt)] <- avg_SL_sd_pt
data$WASO_sd_pt[is.na(data$WASO_sd_pt) & !is.na(data$WASO_m_pt)] <- avg_WASO_sd_pt

### sd
# average SD of ISI
avg_sd_ISI <- mean(data$sd[data$measure == "ISI" & !is.na(data$sd)], 
                   na.rm = TRUE)
# impute
data$sd[data$measure == "ISI" & is.na(data$sd) & !is.na(data$m)] <- avg_sd_ISI
data$sd_pt[data$measure_pt == "ISI" & is.na(data$sd_pt) & !is.na(data$m_pt)] <- avg_sd_ISI

# average SD of SE
avg_sd_SE <- mean(data$sd[data$measure == "SE" & !is.na(data$sd)], 
                   na.rm = TRUE)
# impute
data$sd[data$measure == "SE" & is.na(data$sd) & !is.na(data$m)] <- avg_sd_SE
data$sd_pt[data$measure == "SE" & is.na(data$sd_pt) & !is.na(data$m_pt)] <- avg_sd_SE

##impute r -----
data$r.raw <- data$r
data$r.imputed <- NA

for (i in 1:nrow(data)) {
  if (is.na(data$r[i])) {
    if (!is.na(data$m[i]) & !is.na(data$sd[i])) {
      if (data$measure[i] == "ISI") {
        data$r.imputed[i] <- round(data$n_cont[i] * pnorm((7.5 - data$m[i]) / data$sd[i]), 0)
      } else if (data$measure[i] == "SE") {
        data$r.imputed[i] <- round(data$n_cont[i] * pnorm((data$m[i] - 85) / data$sd[i]), 0)
      } else if (data$measure[i] == "SL") {
        data$r.imputed[i] <- round(data$n_cont[i] * pnorm((30 - data$m[i]) / data$sd[i]), 0)
      }
      data$r[i] <- ifelse(!is.na(data$r.raw[i]), data$r.raw[i], data$r.imputed[i])
    }
  }
}

# impute r_pt
data$r_pt.raw <- data$r_pt
data$r_pt.imputed <- NA

for (i in 1:nrow(data)) {
  if (is.na(data$r_pt[i])) {
    if (!is.na(data$m_pt[i]) & !is.na(data$sd_pt[i])) {
      if (!is.na(data$measure_pt[i]) && data$measure_pt[i] == "ISI") {
        data$r_pt.imputed[i] <- round(data$n_cont_pt[i] * pnorm((7.5 - data$m_pt[i]) / data$sd_pt[i]), 0)
      } else if (!is.na(data$measure_pt[i]) && data$measure_pt[i] == "SE") {
        data$r_pt.imputed[i] <- round(data$n_cont_pt[i] * pnorm((data$m_pt[i] - 85) / data$sd_pt[i]), 0)
      } else if (!is.na(data$measure_pt[i]) && data$measure_pt[i] == "PSQI") {
        data$r_pt.imputed[i] <- round(data$n_cont_pt[i] * pnorm((5.5 - data$m_pt[i]) / data$sd_pt[i]), 0)
      } else if (!is.na(data$measure_pt[i]) && data$measure_pt[i] == "SL") {
        data$r_pt.imputed[i] <- round(data$n_cont_pt[i] * pnorm((30 - data$m_pt[i]) / data$sd_pt[i]), 0)
      }
      data$r_pt[i] <- ifelse(!is.na(data$r_pt.raw[i]), data$r_pt.raw[i], data$r_pt.imputed[i])
      
    }
  }
}

## view -----
view(data)


# data for CINeMA ----
data_subset <- data %>%
  filter(!is.na(r)) %>%
  select(id = study, t, n = n_randomized, r, rob, indirectness) %>%
  mutate(rob = ifelse(rob == "S", "M", rob))
write.csv(data_subset, file = "W2I_CINeMA.csv", row.names = FALSE)

