# League table -----
# Create a CSV file with league table for random effects model
league_nma <- netleague(net_nma, digits = 2, bracket = "(", separator = " to ",seq = netrank(net_nma))
write.table(league_nma$random, file = "league_nma.csv",
            row.names = FALSE, col.names = FALSE, sep = ",")

# pairwise meta-analyses-----
png("netpairwise.png", width = 500, height = 600) 
net_nma %>% netpairwise() %>% forest(leftcols = c("studlab"),xlim=c(0.02,20))
dev.off()  

# RoB2 -----
rob2<-data %>% select (study, D1=D1, D2=D2, D3=D3, D4=D4, D5=Selection, rob) %>%
  group_by(study)%>%
  slice(1)
write.table(rob2, file = "rob2.csv",
            row.names = FALSE, col.names = FALSE, sep = ",")

# Comparing τ2 against empirical distributions-----
d1=rnorm(1000000, mean = -1.09, sd= 1.27)
quantile(exp(d1), c(0.025,0.5, .975)) 
mean(d1>log(0.0206))