# NMA ---------------------------------------------------------------------
# +BUILD -------------------------------------------------------------------
# NMA
## Format trial data

df_nma <- netmeta::pairwise(
  treat = t,
  event = r,
  n = n_randomized,
  sm = "OR",
  data = filter(data,!is.na(data$r)),
  studlab = study
)
#head(df_nma)

# +ANALYZE -----------------------------------------------------------------
# for NMA run:
net_nma <- netmeta(TE, seTE, treat1, treat2, studlab,
                       data = df_nma, ref = "Pharmacotherapy",
                       sm = "OR", fixed = FALSE, small = "undesirable")
net_nma

#x<-data %>% filter (!is.na(r)) 
#sum(x$n_randomized)

# p-score (SUCRA for frequentist NMA)
netrank(x=net_nma, 
        small.values="bad",
        sort = TRUE)

## Network graph
netgraph(net_nma,
         seq = "optimal",
         col = "black", plastic = FALSE,
         points = TRUE, pch = 21, cex.points = 2.5,
         col.points = "black",
         bg.points = "gray",
         # thickness = "se.fixed", #alternative choice
         thickness = "number.of.studies",
         multiarm = FALSE,
         number.of.studies = TRUE)

# global
# read the one in the bottom line "Between designs"
decomp.design(net_nma)

# local
netsplit(net_nma) # here you can check which (and how many) loops show inconsistencies between direct and indirect TEs.

## Forest plot
forest(net_nma, xlim = c(0.5, 5),sortvar = -Pscore,
       smlab = paste("Remission \n (Random Effects Model)"),
       label.left = "Favours Pharmacotherapy    ",
       label.right = "  Favors Intervention",)

## begin: prediction interval
net_nma_split<-netsplit(net_nma)
forest(net_nma_split,fontsize=6,spacing=0.5,addrow.subgroups=FALSE)

png("prediction_interval.png", width = 500, height = 350)    # prepare device
forest(net_nma_split,fontsize=8,spacing=0.75,show="all", 
       only.reference=FALSE,prediction=TRUE, direct=TRUE,indirect=TRUE)
dev.off()   

## end: prediction interval

## League table
# Create a CSV file with league table for random effects model
league_nma <- netleague(net_nma, digits = 2, bracket = "(", separator = " to ",seq = netrank(net_nma))
league_nma
write.table(league_nma$random, file = "league_nma_CBTI.csv",
            row.names = FALSE, col.names = FALSE, sep = ",")

# NMA posttreatment ---------------------------------------------------------------------
# +BUILD -------------------------------------------------------------------
# NMA
## Format trial data
df_nma_com_pt <- netmeta::pairwise(
  treat = t,
  event = r_pt,
  n = n_pt_randomized,
  sm = "OR",
  data = data,
  studlab = study
)
#head(df_nma)

# +ANALYZE -----------------------------------------------------------------
# for NMA run:
net_nma_pt <- netmeta(TE, seTE, treat1, treat2, studlab,
                            data = df_nma_com_pt, ref = "Pharmacotherapy",
                            sm = "OR", fixed = FALSE, small = "undesirable")
net_nma_pt

# p-score (SUCRA for frequentist NMA)
netrank(x=net_nma_pt, 
        small.values="bad",
        sort = TRUE)

## Network graph
netgraph(net_nma_pt,
         seq = "optimal",
         col = "black", plastic = FALSE,
         points = TRUE, pch = 21, cex.points = 2.5,
         col.points = "black",
         bg.points = "gray",
         # thickness = "se.fixed", #alternative choice
         thickness = "number.of.studies",
         multiarm = FALSE,
         number.of.studies = TRUE)

# global
decomp.design(net_nma_pt)

# local
netsplit(net_nma_pt) # here you can check which (and how many) loops show inconsistencies between direct and indirect TEs.

## Forest plot
forest(net_nma_pt, xlim = c(0.5, 20),sortvar = c("CBT-I","Combination","Pharmacotherapy"),
       smlab = paste("Remission at posttreatment\n (Random Effects Model)"),
       label.left = "Favours Pharmacotherapy    ",
       label.right = "  Favors Intervention",)
## begin: prediction interval
net_nma_split_pt<-netsplit(net_nma_pt)
forest(net_nma_split_pt,fontsize=6,spacing=0.5,addrow.subgroups=FALSE)

png("prediction_interval.png", width = 400, height = 1750)    # prepare device
forest(net_nma_split_pt,fontsize=8,spacing=0.75,show="all", 
       only.reference=FALSE,prediction=TRUE, direct=FALSE,indirect=FALSE)
dev.off()   

## end: prediction interval

## metaprop ------
# calculate CER
data_metaprop<-data%>%filter(t=="Pharmacotherapy")%>%
  filter(!is.na(r))
metaprop(data_metaprop$r,
         data_metaprop$n_randomized,
         studlab=data_metaprop$study,
         data=data_metaprop,
         method = "Inverse")

data_metaprop<-data%>%filter(t=="Pharmacotherapy")%>%
  filter(!is.na(n_dropout))
metaprop(data_metaprop$n_dropout,
         data_metaprop$n_randomized,
         studlab=data_metaprop$study,
         data=data_metaprop,
         method = "Inverse")

data_metaprop<-data%>%filter(t=="Pharmacotherapy")%>%
  filter(!is.na(r_pt))
metaprop(data_metaprop$r_pt,
         data_metaprop$n_pt_randomized,
         studlab=data_metaprop$study,
         data=data_metaprop,
         method = "Inverse")

data_metaprop<-data%>%filter(t=="Pharmacotherapy")%>%
  filter(!is.na(n_dropout_pt))
metaprop(data_metaprop$n_dropout_pt,
         data_metaprop$n_pt_randomized,
         studlab=data_metaprop$study,
         data=data_metaprop,
         method = "Inverse")

data_metaprop<-data%>%filter(t=="CBT-I")%>%
  filter(!is.na(r))
metaprop(data_metaprop$r,
         data_metaprop$n_randomized,
         studlab=data_metaprop$study,
         data=data_metaprop,
         method = "Inverse")
