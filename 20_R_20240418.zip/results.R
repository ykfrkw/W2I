cat("\014")   ###clears console

# 1. Primary outcome
net_nma
# 2. Acceptability: dropouts for any reason at long-term follow-up (dichotomous)
net_nma_2
# 3. Sleep diary measures at long-term follow-up (continuous)
# 3.1. Sleep efficiency at long-term follow-up (%)
net_nma_31
# 3.2. Total sleep time at long-term follow-up (minutes)
net_nma_32
# 3.3. Sleep latency at long-term follow-up (minutes)
net_nma_33
# 3.4. Wake after sleep onset at long-term follow-up (minutes)
net_nma_34
# 4. Efficacy at long-term follow-up (continuous)
net_nma_4

# 5. Efficacy at post-treatment: remission defined as reaching a satisfactory state at endpoint measured by any validated self-reported scale (dichotomous)
net_nma_pt
# 6. Acceptability: dropouts for any reason at post-treatment (dichotomous)
net_nma_6
# 7. Sleep diary measures at post-treatment (continuous)
# 7.1. Sleep efficiency at post-treatment (%)
net_nma_71
# 7.2. Total sleep time at post-treatment (minutes)
net_nma_72
# 7.3. Sleep latency at post-treatment (minutes)
net_nma_73
# 7.4. Wake after sleep onset at post-treatment (minutes)
net_nma_74
# 8. Efficacy at post-treatment (continuous)
net_nma_8

