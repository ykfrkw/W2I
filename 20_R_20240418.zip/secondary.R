# 2. Acceptability: dropouts for any reason at long-term follow-up (dichotomous)　-----
data$n_dropout<-as.numeric(data$n_dropout)
data2<-data%>%filter(study!="Vallieres2005")
df_nma_2 <- netmeta::pairwise(
  treat = t,
  event = n_dropout,
  n = n_randomized,
  sm = "OR",
  data = data2,
  studlab = study
)

# for NMA run:
net_nma_2 <- netmeta(TE, seTE, treat1, treat2, studlab,
                   data = df_nma_2, ref = "Pharmacotherapy",
                   sm = "OR", fixed = FALSE, small = "desirable")
net_nma_2

# # p-score (SUCRA for frequentist NMA)
# netrank(x=net_nma_2, 
#         small.values="good",
#         sort = TRUE)
# 
# netgraph(net_nma_2,
#          seq = "optimal",
#          col = "black", plastic = FALSE,
#          points = TRUE, pch = 21, cex.points = 2.5,
#          col.points = "black",
#          bg.points = "gray",
#          # thickness = "se.fixed", #alternative choice
#          thickness = "number.of.studies",
#          multiarm = FALSE,
#          number.of.studies = TRUE)
# 
# ## Forest plot
# forest(net_nma_2, xlim = c(0.2, 2),sortvar = c("CBT-I","Combination","Pharmacotherapy"),
#        smlab = paste("Dropout \n (Random Effects Model)"),
#        label.left = "Favours Intervention    ",
#        label.right = "  Favors Pharmacotherapy",)

# 3. Sleep diary measures at long-term follow-up (continuous)
# 3.1. Sleep efficiency at long-term follow-up (%) -----

df_nma_31 <- netmeta::pairwise(
  treat = t,
  n = SE_n,
  mean = SE_m,
  sd = SE_sd,
  sm = "MD",
  data = data,
  studlab = study
)

# for NMA run:
net_nma_31 <- netmeta(TE, seTE, treat1, treat2, studlab,
                     data = df_nma_31, ref = "Pharmacotherapy",
                     sm = "MD", fixed = FALSE, small = "undesirable")
net_nma_31

# # p-score (SUCRA for frequentist NMA)
# netrank(x=net_nma_31, 
#         small.values="bad",
#         sort = TRUE)
# 
# ## Forest plot
# forest(net_nma_31, xlim = c(-5, 15),sortvar = c("CBT-I","Combination","Pharmacotherapy"),
#        smlab = paste("Sleep efficiency \n (Random Effects Model)"),
#        label.left = "Favours Pharmacotherapy    ",
#        label.right = "  Favors Intervention",)

# 3.2. Total sleep time at long-term follow-up (minutes) -----
df_nma_32 <- netmeta::pairwise(
  treat = t,
  n = TST_n,
  mean = TST_m,
  sd = TST_sd,
  sm = "MD",
  data = data,
  studlab = study
)

# for NMA run:
net_nma_32 <- netmeta(TE, seTE, treat1, treat2, studlab,
                      data = df_nma_32, ref = "Pharmacotherapy",
                      sm = "MD", fixed = FALSE, small = "undesirable")
net_nma_32

# # p-score (SUCRA for frequentist NMA)
# netrank(x=net_nma_32, 
#         small.values="bad",
#         sort = TRUE)
# 
# ## Forest plot
# forest(net_nma_32, xlim = c(-60, 60),sortvar = c("CBT-I","Combination","Pharmacotherapy"),
#        smlab = paste("Total sleep time \n (Random Effects Model)"),
#        label.left = "Favours Pharmacotherapy    ",
#        label.right = "  Favors Intervention",)


# 3.3. Sleep latency at long-term follow-up (minutes) ------
df_nma_33 <- netmeta::pairwise(
  treat = t,
  n = SL_n,
  mean = SL_m,
  sd = SL_sd,
  sm = "MD",
  data = data,
  studlab = study
)

# for NMA run:
net_nma_33 <- netmeta(TE, seTE, treat1, treat2, studlab,
                      data = df_nma_33, ref = "Pharmacotherapy",
                      sm = "MD", fixed = FALSE, small = "desirable")
net_nma_33

# # p-score (SUCRA for frequentist NMA)
# netrank(x=net_nma_33, 
#         small.values="good",
#         sort = TRUE)
# 
# ## Forest plot
# forest(net_nma_33, xlim = c(-60, 60),sortvar = c("CBT-I","Combination","Pharmacotherapy"),
#        smlab = paste("Sleep latency \n (Random Effects Model)"),
#        label.left = "Favours Intervention    ",
#        label.right = "  Favors Pharmacotherapy",)


# 3.4. Wake after sleep onset at long-term follow-up (minutes) -----
df_nma_34 <- netmeta::pairwise(
  treat = t,
  n = WASO_n,
  mean = WASO_m,
  sd = WASO_sd,
  sm = "MD",
  data = data,
  studlab = study
)

# for NMA run:
net_nma_34 <- netmeta(TE, seTE, treat1, treat2, studlab,
                      data = df_nma_34, ref = "Pharmacotherapy",
                      sm = "MD", fixed = FALSE, small = "desirable")
net_nma_34

# # p-score (SUCRA for frequentist NMA)
# netrank(x=net_nma_34, 
#         small.values="good",
#         sort = TRUE)
# 
# ## Forest plot
# forest(net_nma_34, xlim = c(-60, 60),sortvar = c("CBT-I","Combination","Pharmacotherapy"),
#        smlab = paste("Wake after sleep onset \n (Random Effects Model)"),
#        label.left = "Favours Intervention    ",
#        label.right = "  Favors Pharmacotherapy",)

# 4. Efficacy at long-term follow-up (continuous) ------
data <- data %>%
  mutate(m_standardized = if_else(measure == "SE", m * -1, m))

df_nma_4 <- netmeta::pairwise(
  treat = t,
  n = n_cont,
  mean = m_standardized,
  sd = sd,
  sm = "SMD",
  data = data,
  studlab = study
)

# for NMA run:
net_nma_4 <- netmeta(TE, seTE, treat1, treat2, studlab,
                      data = df_nma_4, ref = "Pharmacotherapy",
                      sm = "SMD", fixed = FALSE, small = "desirable")
net_nma_4

# # p-score (SUCRA for frequentist NMA)
# netrank(x=net_nma_4, 
#         small.values="good",
#         sort = TRUE)
# 
# ## Forest plot
# forest(net_nma_4, xlim = c(-1, 1),sortvar = c("CBT-I","Combination","Pharmacotherapy"),
#        smlab = paste("Insomnia severity \n (Random Effects Model)"),
#        label.left = "Favours Intervention    ",
#        label.right = "  Favors Pharmacotherapy",)

# 5. Efficacy at post-treatment: remission defined as reaching a satisfactory state at endpoint measured by any validated self-reported scale (dichotomous) -----
## in the primary.R

# 6. Acceptability: dropouts for any reason at post-treatment (dichotomous) -----
data$n_dropout_pt<-as.numeric(data$n_dropout_pt)

df_nma_6 <- netmeta::pairwise(
  treat = t,
  event = n_dropout_pt,
  n = n_randomized,
  sm = "OR",
  data = data2,
  studlab = study
)

# for NMA run:
net_nma_6 <- netmeta(TE, seTE, treat1, treat2, studlab,
                     data = df_nma_6, ref = "Pharmacotherapy",
                     sm = "OR", fixed = FALSE, small = "desirable")
net_nma_6

# # p-score (SUCRA for frequentist NMA)
# netrank(x=net_nma_6, 
#         small.values="good",
#         sort = TRUE)
# 
# ## Forest plot
# forest(net_nma_6, xlim = c(0.1, 2),sortvar = c("CBT-I","Combination","Pharmacotherapy"),
#        smlab = paste("Dropout posttreatment\n (Random Effects Model)"),
#        label.left = "Favours Intervention    ",
#        label.right = "  Favors Pharmacotherapy",)


# 7. Sleep diary measures at post-treatment (continuous) -----
# 7.1. Sleep efficiency at post-treatment (%) -----
df_nma_71 <- netmeta::pairwise(
  treat = t,
  n = SE_n_pt,
  mean = SE_m_pt,
  sd = SE_sd_pt,
  sm = "MD",
  data = data,
  studlab = study
)

# for NMA run:
net_nma_71 <- netmeta(TE, seTE, treat1, treat2, studlab,
                      data = df_nma_71, ref = "Pharmacotherapy",
                      sm = "MD", fixed = FALSE, small = "undesirable")
net_nma_71

# # p-score (SUCRA for frequentist NMA)
# netrank(x=net_nma_71, 
#         small.values="bad",
#         sort = TRUE)
# 
# ## Forest plot
# forest(net_nma_71, xlim = c(-5, 15),sortvar = c("CBT-I","Combination","Pharmacotherapy"),
#        smlab = paste("Sleep efficiency posttreatment\n (Random Effects Model)"),
#        label.left = "Favours Pharmacotherapy    ",
#        label.right = "  Favors Intervention",)


# 7.2. Total sleep time at post-treatment (minutes) -----
df_nma_72 <- netmeta::pairwise(
  treat = t,
  n = TST_n_pt,
  mean = TST_m_pt,
  sd = TST_sd_pt,
  sm = "MD",
  data = data,
  studlab = study
)

# for NMA run:
net_nma_72 <- netmeta(TE, seTE, treat1, treat2, studlab,
                      data = df_nma_72, ref = "Pharmacotherapy",
                      sm = "MD", fixed = FALSE, small = "undesirable")
net_nma_72

# # p-score (SUCRA for frequentist NMA)
# netrank(x=net_nma_72, 
#         small.values="bad",
#         sort = TRUE)
# 
# ## Forest plot
# forest(net_nma_72, xlim = c(-60, 60),sortvar = c("CBT-I","Combination","Pharmacotherapy"),
#        smlab = paste("Total sleep time posttreatment\n (Random Effects Model)"),
#        label.left = "Favours Pharmacotherapy    ",
#        label.right = "  Favors Intervention",)



# 7.3. Sleep latency at post-treatment (minutes) -----
df_nma_73 <- netmeta::pairwise(
  treat = t,
  n = SL_n_pt,
  mean = SL_m_pt,
  sd = SL_sd_pt,
  sm = "MD",
  data = data,
  studlab = study
)

# for NMA run:
net_nma_73 <- netmeta(TE, seTE, treat1, treat2, studlab,
                      data = df_nma_73, ref = "Pharmacotherapy",
                      sm = "MD", fixed = FALSE, small = "desirable")
net_nma_73

# # p-score (SUCRA for frequentist NMA)
# netrank(x=net_nma_73, 
#         small.values="good",
#         sort = TRUE)
# 
# ## Forest plot
# forest(net_nma_73, xlim = c(-60, 60),sortvar = c("CBT-I","Combination","Pharmacotherapy"),
#        smlab = paste("Sleep latency posttreatment \n (Random Effects Model)"),
#        label.left = "Favours Intervention    ",
#        label.right = "  Favors Pharmacotherapy",)


# 7.4. Wake after sleep onset at post-treatment (minutes) -----
df_nma_74 <- netmeta::pairwise(
  treat = t,
  n = WASO_n_pt,
  mean = WASO_m_pt,
  sd = WASO_sd_pt,
  sm = "MD",
  data = data,
  studlab = study
)

# for NMA run:
net_nma_74 <- netmeta(TE, seTE, treat1, treat2, studlab,
                      data = df_nma_74, ref = "Pharmacotherapy",
                      sm = "MD", fixed = FALSE, small = "desirable")
net_nma_74

# # p-score (SUCRA for frequentist NMA)
# netrank(x=net_nma_74, 
#         small.values="good",
#         sort = TRUE)
# 
# ## Forest plot
# forest(net_nma_74, xlim = c(-60, 60),sortvar = c("CBT-I","Combination","Pharmacotherapy"),
#        smlab = paste("Wake after sleep onset posttreatment\n (Random Effects Model)"),
#        label.left = "Favours Intervention    ",
#        label.right = "  Favors Pharmacotherapy",)




# 8. Efficacy at post-treatment (continuous) -----
data <- data %>%
  mutate(m_standardized_pt = if_else(measure == "SE", m_pt * -1, m_pt))

df_nma_8 <- netmeta::pairwise(
  treat = t,
  n = n_cont_pt,
  mean = m_standardized_pt,
  sd = sd,
  sm = "SMD",
  data = data,
  studlab = study
)

# for NMA run:
net_nma_8 <- netmeta(TE, seTE, treat1, treat2, studlab,
                     data = df_nma_8, ref = "Pharmacotherapy",
                     sm = "SMD", fixed = FALSE, small = "desirable")
net_nma_8

# # p-score (SUCRA for frequentist NMA)
# netrank(x=net_nma_8, 
#         small.values="good",
#         sort = TRUE)
# 
# ## Forest plot
# forest(net_nma_8, xlim = c(-1, 1),sortvar = c("CBT-I","Combination","Pharmacotherapy"),
#        smlab = paste("Insomnia severity posttreatment\n (Random Effects Model)"),
#        label.left = "Favours Intervention    ",
#        label.right = "  Favors Pharmacotherapy",)


