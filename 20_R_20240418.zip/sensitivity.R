#sensitivity
# 1. Excluding studies without formal diagnosis of insomnia
# -Vgotzas2020
data_S1<- data %>% filter(study!="Vgotzas2020")
df_nma_S1 <- netmeta::pairwise(
  treat = t,
  event = r,
  n = n_randomized,
  sm = "OR",
  data = filter(data_S1,!is.na(data_S1$r)),
  studlab = study
)
net_nma_S1 <- netmeta(TE, seTE, treat1, treat2, studlab,
                   data = df_nma_S1, ref = "Pharmacotherapy",
                   sm = "OR", fixed = FALSE, small = "undesirable")
net_nma_S1

# 2. Excluding studies focusing on patients with comorbidities (both physical and psychological)
# NA

# 3. Excluding studies with overall high dropout rate (20% or more)
# -Jacobs2004, -Morin1999, -Morin2009, -Morin2020, 
# -Siversten2006, -Vallieres2005, -Vgotzas2020

data_S3<- data %>% 
  filter(!study %in% c("Jacobs2004", "Morin1999", "Morin2009", "Morin2020", 
                       "Siversten2006", "Vallieres2005", "Vgotzas2020"))
df_nma_S3 <- netmeta::pairwise(
  treat = t,
  event = r,
  n = n_randomized,
  sm = "OR",
  data = filter(data_S3,!is.na(data_S3$r)),
  studlab = study
)
net_nma_S3 <- netmeta(TE, seTE, treat1, treat2, studlab,
                      data = df_nma_S3, ref = "Pharmacotherapy",
                      sm = "OR", fixed = FALSE, small = "undesirable")
net_nma_S3

# 4. Excluding studies at high overall risk of bias
# 

data_S4<- data %>% 
  filter(rob != "H")

df_nma_S4 <- netmeta::pairwise(
  treat = t,
  event = r,
  n = n_randomized,
  sm = "OR",
  data = filter(data_S4,!is.na(data_S4$r)),
  studlab = study
)
net_nma_S4 <- netmeta(TE, seTE, treat1, treat2, studlab,
                      data = df_nma_S4, ref = "Pharmacotherapy",
                      sm = "OR", fixed = FALSE, small = "undesirable")
net_nma_S4
 
# 5. Excluding arms with switching 
#    (excluding CBT-I -> com, CBT-I -> pha, pha -> CBT-I, pha -> com) (Post hoc)
# 
data_t2 <- data_raw %>% dplyr::filter(!is.na(t2)) %>%
  select(study,t2,r,n_randomized,n_cont,m,sd,measure)

data_t4 <- data_t2 %>%
  filter(t2!="CBT-I -> Pharmacotherapy")%>%
  filter(t2!="Pharmacotherapy -> CBT-I")%>%
  filter(t2!="Pharmacotherapy -> Combination")%>%
  mutate(t2_raw = t2,
         t4 = as.character(t2),
         t4 = case_when(
           t4 == "CBT-I -> CBT-I" ~ "CBT-I",
           t4 == "CBT-I -> Combination" ~ "CBT-I",
           t4 == "CBT-I -> nat" ~ "CBT-I",
           t4 == "Combination -> CBT-I" ~ "Combination",
           t4 == "Combination -> Pharmacotherapy" ~ "Combination",
           t4 == "Combination -> nat" ~ "Combination",
           t4 == "Combination -> Combination" ~ "Combination",
           t4 == "Pharmacotherapy -> nat" ~ "Pharmacotherapy",
           t4 == "Pharmacotherapy -> Pharmacotherapy" ~ "Pharmacotherapy",
           TRUE ~ as.character(t4)
         )
  ) %>% filter(t2!="Placebo")


data_t4$n_randomized <- as.numeric(data_t4$n_randomized)
data_t4$r <- as.numeric(data_t4$r)

data_t4$n_cont <- as.numeric(data_t4$n_cont)
data_t4$m <- as.numeric(data_t4$m)
data_t4$sd <- as.numeric(data_t4$sd)

data_t4$sd[data_t4$measure == "ISI" & is.na(data_t4$sd) & !is.na(data_t4$m)] <- avg_sd_ISI
data_t4$sd[data_t4$measure == "SE" & is.na(data_t4$sd) & !is.na(data_t4$m)] <- avg_sd_SE

data_t4$r.raw <-data_t4$r
data_t4$r.imputed <- NA

for (i in 1:nrow(data_t4)) {
  if (is.na(data_t4$r[i])) {
    if (!is.na(data_t4$m[i]) & !is.na(data_t4$sd[i])) {
      if (data_t4$measure[i] == "ISI") {
        data_t4$r.imputed[i] <- round(data_t4$n_cont[i] * pnorm((7.5 - data_t4$m[i]) / data_t4$sd[i]), 0)
      } else if (data_t4$measure[i] == "SE") {
        data_t4$r.imputed[i] <- round(data_t4$n_cont[i] * pnorm((data_t4$m[i] - 85) / data_t4$sd[i]), 0)
      } else if (data_t4$measure[i] == "SL") {
        data_t4$r.imputed[i] <- round(data_t4$n_cont[i] * pnorm((30 - data_t4$m[i]) / data_t4$sd[i]), 0)
      }
      data_t4$r[i] <- ifelse(!is.na(data_t4$r.raw[i]), data_t4$r.raw[i], data_t4$r.imputed[i])
    }
  }
}


data_t4 <- data_t4 %>% select(study,t4,r,n_randomized) %>% 
  filter(!is.na(r))%>%
  group_by(study,t4) %>% 
  summarise(r = sum(r), n_randomized = sum(n_randomized))

df_nma_t4 <- netmeta::pairwise(
  treat = t4,
  event = r,
  n = n_randomized,
  sm = "OR",
  data = data_t4,
  studlab = study
)

df_nma_t4 <- filter(df_nma_t4, !is.na(TE))

net_nma_t4 <- netmeta(TE, seTE, treat1, treat2, studlab,
                      data = df_nma_t4, ref = "Pharmacotherapy",
                      sm = "OR", fixed = FALSE, small = "undesirable")
net_nma_t4



# 6. Categorizing arms using both the initial and the second-step treatments (Post hoc)
# 
data_t2 <- data_raw %>% dplyr::filter(!is.na(t2)) %>%
  select(study,t2,r,n_randomized,n_cont,m,sd,measure)

data_t2 <- data_t2 %>%
  mutate(t2_raw = t2,
         t2 = as.character(t2),
         t2 = case_when(
           # t2 == "Pharmacotherapy -> Pharmacotherapy" ~ "Pharmacotherapy -> nat",
           TRUE ~ as.character(t2)
         )
  ) %>% filter(t2!="Placebo")


data_t2$n_randomized <- as.numeric(data_t2$n_randomized)
data_t2$r <- as.numeric(data_t2$r)

data_t2$n_cont <- as.numeric(data_t2$n_cont)
data_t2$m <- as.numeric(data_t2$m)
data_t2$sd <- as.numeric(data_t2$sd)

data_t2$sd[data_t2$measure == "ISI" & is.na(data_t2$sd) & !is.na(data_t2$m)] <- avg_sd_ISI
data_t2$sd[data_t2$measure == "SE" & is.na(data_t2$sd) & !is.na(data_t2$m)] <- avg_sd_SE

data_t2$r.raw <-data_t2$r
data_t2$r.imputed <- NA

for (i in 1:nrow(data_t2)) {
  if (is.na(data_t2$r[i])) {
    if (!is.na(data_t2$m[i]) & !is.na(data_t2$sd[i])) {
      if (data_t2$measure[i] == "ISI") {
        data_t2$r.imputed[i] <- round(data_t2$n_cont[i] * pnorm((7.5 - data_t2$m[i]) / data_t2$sd[i]), 0)
      } else if (data_t2$measure[i] == "SE") {
        data_t2$r.imputed[i] <- round(data_t2$n_cont[i] * pnorm((data_t2$m[i] - 85) / data_t2$sd[i]), 0)
      } else if (data_t2$measure[i] == "SL") {
        data_t2$r.imputed[i] <- round(data_t2$n_cont[i] * pnorm((30 - data_t2$m[i]) / data_t2$sd[i]), 0)
      }
      data_t2$r[i] <- ifelse(!is.na(data_t2$r.raw[i]), data_t2$r.raw[i], data_t2$r.imputed[i])
    }
  }
}
df_nma_t2 <- netmeta::pairwise(
  treat = t2,
  event = r,
  n = n_randomized,
  sm = "OR",
  data = data_t2,
  studlab = study
)

df_nma_t2 <- filter(df_nma_t2, !is.na(TE))

net_nma_t2 <- netmeta(TE, seTE, treat1, treat2, studlab,
                      data = df_nma_t2, ref = "Pharmacotherapy -> nat",
                      sm = "OR", fixed = FALSE, small = "undesirable")
net_nma_t2

