#prepare datframe
data_transitivity <- df_nma %>% 
  select(study=studlab, treat1, treat2) %>%
  mutate(comparison=paste(treat1, treat2, sep = ":"))
data_transitivity <- data_transitivity %>%
  mutate(
    comparison = case_when(
      comparison == "Pharmacotherapy:Combination" ~ "Combination:Pharmacotherapy",
      comparison == "Pharmacotherapy:CBT-I" ~ "CBT-I:Pharmacotherapy",
      comparison == "Combination:CBT-I" ~ "CBT-I:Combination",
      TRUE ~ comparison
    )
  )

#get year
#get baseline severity

# data_processedからstudyごとのage_mean,baseline_meanを取得
data_processed <- data %>%
  group_by(study) %>%
  mutate(age_mean = sum(age_n * age_m) / sum(age_n)) %>%
  mutate(baseline_m=sum(baseline_n*baseline_m)/sum(baseline_n))%>%
  ungroup()
study_age_mean <- data_processed %>%
  group_by(study) %>%
  summarise(age_mean = mean(age_mean, na.rm = TRUE)) %>%
  ungroup()
study_baseline_mean <- data_processed %>%
  group_by(study) %>%
  summarise(baseline_mean = mean(baseline_m, na.rm = TRUE)) %>%
  ungroup()
study_year <- data_processed %>%
  mutate(year = substr(study, nchar(study) - 3, nchar(study)))%>%
  select(study,year)%>%
  group_by(study)%>%
  slice(1)
study_year$year<-as.numeric(study_year$year)

# add age_mean,baseline_mean, year
data_transitivity <- left_join(data_transitivity, study_age_mean, by = "study")
data_transitivity <- left_join(data_transitivity, study_baseline_mean, by = "study")
data_transitivity <- left_join(data_transitivity, study_year, by = "study")


#publication year
# year -----
gt1 <- with(data_transitivity,                       # Order boxes by median
            reorder(comparison,
                    year,
                    median))

boxplot(
  year ~ gt1,
  data = data_transitivity,
  main = "Publication year",
  cex.axis=0.5,
  xlab="Comparison",
  ylab="Publication year"
  #col = c("pink","lightgreen" ,"lightblue")
)


#mean age
data_transitivity2<-subset(data_transitivity,!(is.na(data_transitivity$age_mean)))

gt2 <- with(data_transitivity2,                       # Order boxes by median
            reorder(comparison,
                    age_mean,
                    median))
boxplot(
  age_mean ~ gt2,
  data = data_transitivity2,
  main = "Age (year)",
  cex.axis=0.5,
  ylim=c(20,70),
  xlab="Comparison",
  ylab="Age (year)"
  #col = c("pink","lightgreen" ,"lightblue")
)



#baseline severity
data_transitivity3<-subset(data_transitivity,!(is.na(data_transitivity$baseline_mean)))

gt3 <- with(data_transitivity3,                       # Order boxes by median
            reorder(comparison,
                    baseline_mean,
                    median))
boxplot(
  baseline_mean ~ gt3,
  data = data_transitivity3,
  main = "Baseline severity (ISI)",
  cex.axis=0.5,
  ylim=c(0,28),
  xlab="Comparison",
  ylab="ISI"
  #col = c("pink","lightgreen" ,"lightblue")
)
